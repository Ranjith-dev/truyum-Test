package com.practice.truyum;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.practice.truyum.model.User;
import com.practice.truyum.service.UserService;

@SpringBootApplication
public class TruyumSpringMineApplication {

	private static Logger logger = LoggerFactory.getLogger(TruyumSpringMineApplication.class);
	static ApplicationContext context = null;
	static UserService userService = null;

	public static void main(String[] args) {
		logger.info("--------Starting------");
		context = SpringApplication.run(TruyumSpringMineApplication.class, args);
		userService = context.getBean(UserService.class);
		
		//Calling the addUser()
		TestAddUser();
	}
	
	static void TestAddUser() {
		logger.info("-----Adding the Users----");
		User user1 = new User(2134,"Ranjith Kumar V");
		User user2 = new User(1234,"Tamil Selvi V");
		
		userService.addUser(user1);
		userService.addUser(user2);	
		
		logger.info("-----Users Added Successfully!!!!----");
	}

}
