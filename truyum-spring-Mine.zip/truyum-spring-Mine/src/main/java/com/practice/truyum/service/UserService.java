package com.practice.truyum.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practice.truyum.model.User;
import com.practice.truyum.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userRepository;
	
	//adding the user using save() of JPA
	@Transactional
	public void addUser(User user) {
		userRepository.save(user);
	}
}
