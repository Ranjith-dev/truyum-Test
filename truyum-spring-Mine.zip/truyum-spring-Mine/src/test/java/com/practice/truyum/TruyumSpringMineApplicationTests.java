package com.practice.truyum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruyumSpringMineApplicationTests {

	@Test
	void contextLoads() {
	}

}
